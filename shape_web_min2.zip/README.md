# SHAPE Session Prep — Minimal

Paste a transcript; get a SHAPE-style influence score and brief context.

Deploy on Render:
- Build: `pip install -r requirements.txt`
- Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`
